<?php
if (!defined('BASEPATH'))
    exit('No direct script access allowed');
class Update_item extends CI_Controller{

	  function __construct()
    {
        parent::__construct();
        $this->load->model('update_item_model');
        $this->load->library('form_validation');
		
    }

public function index()
    { 
	$item = $this->update_item_model->get_all();
	$data = array(
		'item_data' => $item,
		'change' => 12,
	);
$this->load->view('admin', $data);
    }
	
/*public function return()
    { 
	$item = $this->update_item_model->get_all();
	$data = array(
		'item_data' => $item,
		'change' => 14,
	);
$this->load->view('admin', $data);
    }
*/

	public function create() 
    	{
        $data = array(
            'button' => 'add',
            'action' => site_url('/add_item/create_action'),
	    'id' => set_value('id'),
	    'item_name' => set_value('item_name'),
	    'category' => set_value('category'),
	    'qty' => set_value('qty'),
	    'date' => set_value('date'),
		'change'  => 1,
	);
        $this->load->view('admin', $data);
    }
    
    public function create_action() 
    {
//	echo "ssss";
	//exit;
	        $this->form_validation->set_rules('item_name', 'item name', 'required');
	$this->form_validation->set_rules('category', 'category', 'required');
	$this->form_validation->set_rules('qty', 'qty', 'required|numeric');
	$this->form_validation->set_rules('date', 'date', 'required');
	
	$this->form_validation->set_rules('id', 'id', 'trim');

        if ($this->form_validation->run() == FALSE) {
            $this->create();
        } else {
            $data = array(
		'item_name' => $this->input->post('item_name',TRUE),
		'category' => $this->input->post('category',TRUE),
		'qty' => $this->input->post('qty',TRUE),
		'date' => $this->input->post('date',TRUE),
	    );
		
              
            $this->add_item_model->insert($data);
			$data = array(
			   'change' => 1,
			);
            $this->session->set_flashdata('message', 'Item added');
             $this->load->view('admin',$data);
        }
    }
	
	//public function view(){
		
		//$data = array(
		//'change' => 2,
		//);
		//$this->load->view('admin', $data);
		//$this->load->view('admin', $data);
	//}
	
	 public function update() 
    {
	
	/*$this->load->model('give_item_model');
	$data2 = array(
		'item_name' => $this->input->post('prod',TRUE),
		'qty' => $this->input->post('number',TRUE),
		'status' => $this->input->post('status',TRUE),
		'receiver_name' => $this->input->post('name',TRUE),
		'receiver_contact' => $this->input->post('contact',TRUE),
		'destination' => $this->input->post('destination',TRUE),
	);
	$this->give_item_model->insert($data2);
	*/
	$this->load->model('update_item_model');
	$item = $this->update_item_model->get_all();
	$data = array(
		'item_data' => $item,
	);
	   
		$id = $this->input->post('prod', TRUE);
		$num = $this->input->post('number', TRUE);
	if($num>0){
        $row = $this->update_item_model->get_by_id($id);

	// echo $id;
	   $qty1 = $row->qty;
	   $qty2 = $row->original_qty;
	   $qty = $qty1+$num;
	   $qtty = $qty2+$num;
	   //echo $qty;
		//exit;
		
        if ($row) {
		    
            $data = array(
                //'button' => 'Update',
                //'action' => site_url('index.php/give_item/update_action'),
		    'qty' => $qty,
			'original_qty' => $qtty,
			
	    );
		
		//var_dump($data);
		//exit;
		$this->update_item_model->update($id, $data);
		$item = $this->update_item_model->get_all();
		//$this->give_item_model->insert($data);
		$data = array(
		'item_data' => $item,
			'change' => 13,
		);
            $this->load->view('admin', $data);
        } else {
            $this->session->set_flashdata('message', 'Record Not Found');
            $this->load->view('admin', $data);
        }

	}
	else{
	$data = array(
		'item_data'=>$item,
		'change'=>17,
		);
	$this->load->view('admin', $data);
	}

    }
    
    public function update_action() 
    {
       /* $this->_rules();

        if ($this->form_validation->run() == FALSE) {
            $this->update($this->input->post('id', TRUE));
        } else {
            $data = array(
		'qty' => $this->input->post('number',TRUE),
	    );

            $this->Advisory_model->update($this->input->post('id', TRUE), $data);
            $this->session->set_flashdata('message', 'Update Record Success');
	         $advisory = $this->Advisory_model->get_all();
	         $data = array(
			   'change' => 5,
              'advisory_data' => $advisory
             );
            $this->load->view('template',$data);
        }*/
    }
    
    public function delete($id) 
    {
        $row = $this->Advisory_model->get_by_id($id);
        $advisory = $this->Advisory_model->get_all();
	         $data = array(
			   'change' => 5,
              'advisory_data' => $advisory
             );
        if ($row) {
            $this->Advisory_model->delete($id);
            $this->session->set_flashdata('message', 'Delete Record Success');
             $this->load->view('template',$data);
        } else {
            $this->session->set_flashdata('message', 'Record Not Found');
             $this->load->view('template',$data);
        }
    }
	
	public function read() 
    {
	$id = $this->input->post('prod', TRUE);
	$row = $this->add_item_model->get_by_id_replaced($id);
	if ($row) {
            $data = array(
		'id' => $row->id,
		'item_name' => $row->item_name,
		'category' => $row->category,
		'qty' => $row->qty,
		'date' => $row-> date,
		'change' => 3,
	    );
            $this->load->view('admin', $data);
        } else {
            $this->session->set_flashdata('message', 'Record Not Found');
            redirect(site_url('admin'));
        }
    }

	 public function _rules() 
    {
	$this->form_validation->set_rules('item_name', 'item name', 'trim|required');
	$this->form_validation->set_rules('category', 'category', 'trim|required|');
	$this->form_validation->set_rules('qty', 'qty', 'trim|required|numeric');
	$this->form_validation->set_rules('date', 'date', 'trim|required');
	
	$this->form_validation->set_rules('id', 'id', 'trim');
	$this->form_validation->set_error_delimiters('<span class="text-danger">', '</span>');
    }
	}
	
	
	?>
