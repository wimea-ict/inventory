
        <!-- Main content -->
        <section class='content'>
          <div class='row'>
            <div class='col-xs-12'>
              <div class='box'>
                <div class='box-header'>
                  <h3 class='box-title'>RETURN FORM </h3>
                </div><!-- /.box-header -->
                <div class='box-body'>
     <!--   <table class="table table-bordered table-striped" id="mytable">
            <thead>
                <tr>
                    <th width="80px">No</th>
		    <th>Item name</th>
			<th>Category</th>
		    <th>Action</th>
                </tr>
            </thead>
	    <tbody>-->
		<div class="form-panel">
		<!--<form class="form-horizontal style-form" action = "/item_list/read" method = "POST">-->
		<?php echo form_open('/return_item/update_action')?>
		<div class="form-group">
                              <label class="col-sm-2 col-sm-2 control-label">Item Name</label>
                              <div class="col-sm-10">
							 <?php  $reg = $this->db->get_where('product',array('id'=>$item_name)); ?>
                                 <?php foreach($reg->result_array() as $p){
				 echo "<input type='text' class='form-control' name='item_name' value= ' ".$p['item_name']."' disabled />";
				 } ?>
                              </div><br/><br/><br/><br/>
			<div class="form-group">
                              <label class="col-sm-2 col-sm-2 control-label">Number Returned</label>
                              <div class="col-sm-10">
							  <input type="hidden" class="form-control" name="names" value="<?php echo $item_name; ?>" />
                                  <input type="text" class="form-control" name="numm" value="<?php echo $qty; ?>" />
								    <input type="hidden" class="form-control" name="id" value="<?php echo $id; ?>" />
                              </div><br/><br/><br/><br/>
							  <div class="form-group">
                              <label class="col-sm-2 col-sm-2 control-label">Status</label>
                              <div class="col-sm-10">
                                  <input type="text" class="form-control" name="status" value="<?php echo $status; ?>" disabled/>
                              </div><br/><br/><br/><br/>
							  <div class="form-group">
                              <label class="col-sm-2 col-sm-2 control-label">Receiver</label>
                              <div class="col-sm-10">
                                  <input type="text" class="form-control" name="receiver_name" value="<?php echo $receiver_name; ?>" disabled/>
                              </div><br/><br/><br/><br/>
							  <div class="form-group">
                              <label class="col-sm-2 col-sm-2 control-label">Contact</label>
                              <div class="col-sm-10">
                               <input type="text" class="form-control" name="receiver_contact" value="<?php echo $receiver_contact;?>" disabled/>
                              </div><br/><br/><br/><br/>
							  <div class="form-group">
                              <label class="col-sm-2 col-sm-2 control-label">Location</label>
                              <div class="col-sm-10">
							 <?php  $reg = $this->db->get_where('item_out',array('id'=>$id)); ?>
                                 <?php foreach($reg->result_array() as $p){
				 echo "<input type='text' class='form-control' name='dest' value= ' ".$p['destination']."' disabled />";
				 } ?>
                              </div><br/><br/><br/><br/>
			
						
							 
			<input type="submit" name="Update" value="Submit"/>
			
			<!--<a href="index.php/item_list/read"><button type="submit" name="check" class="btn btn-primary" align = "right"><span class="glyphicon glyphicon-check"></span> Submit</button></a>-->
			</div>
			<!--</form> -->
			<?php echo form_close()?>
			</div>
        <!--    </tbody>
        </table> -->
        <script src="<?php echo base_url('assets/frameworks/jquery/jquery.min.js') ?>"></script>
        <script src="<?php echo base_url('assets/plugins/datatables/jquery.dataTables.js') ?>"></script>
        <script src="<?php echo base_url('assets/plugins/datatables/dataTables.bootstrap.js') ?>"></script>
        <script type="text/javascript">
            $(document).ready(function () {
                $("#mytable").dataTable();
            });
        </script>
                    </div><!-- /.box-body -->
              </div><!-- /.box -->
            </div><!-- /.col -->
          </div><!-- /.row -->
        </section><!-- /.content -->