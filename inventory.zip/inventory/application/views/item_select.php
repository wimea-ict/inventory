
        <!-- Main content -->
        <section class='content'>
          <div class='row'>
            <div class='col-xs-12'>
              <div class='box'>
                <div class='box-header'>
                  <h3 class='box-title'>ITEM LIST </h3>
                </div><!-- /.box-header -->
                <div class='box-body'>
     <!--   <table class="table table-bordered table-striped" id="mytable">
            <thead>
                <tr>
                    <th width="80px">No</th>
		    <th>Item name</th>
			<th>Category</th>
		    <th>Action</th>
                </tr>
            </thead>
	    <tbody>-->
		<div class="form-panel">
		<!--<form class="form-horizontal style-form" action = "/item_list/read" method = "POST">-->
		<?php echo form_open('/item_list/read')?>
		<div class="form-group">
                              <label class="col-sm-2 col-sm-2 control-label">Select Item</label>
		<select name="prod"  class="form-control"> 
            <?php
            $start = 0;
			
						        	
            foreach ($item_data as $item)
            {
			  //  $reg = $this->db->get_where('product',array('id'=>$item->id));
                ?>
                <tr>
		    <?php echo ++$start ?></td>
			<option value = "<?php echo $item->id ?>"><?php echo $item->item_name ?></option>
			
			
                <?php
            }
            ?>
			</select>&nbsp; &nbsp; &nbsp;<br/>
			<input type="submit" name="submit" value="Submit"/>
			<!--<a href="index.php/item_list/read"><button type="submit" name="check" class="btn btn-primary" align = "right"><span class="glyphicon glyphicon-check"></span> Submit</button></a>-->
			</div>
			<!--</form> -->
			<?php echo form_close()?>
			</div>
        <!--    </tbody>
        </table> -->
        <script src="<?php echo base_url('assets/frameworks/jquery/jquery.min.js') ?>"></script>
        <script src="<?php echo base_url('assets/plugins/datatables/jquery.dataTables.js') ?>"></script>
        <script src="<?php echo base_url('assets/plugins/datatables/dataTables.bootstrap.js') ?>"></script>
        <script type="text/javascript">
            $(document).ready(function () {
                $("#mytable").dataTable();
            });
        </script>
                    </div><!-- /.box-body -->
              </div><!-- /.box -->
            </div><!-- /.col -->
          </div><!-- /.row -->
        </section><!-- /.content -->