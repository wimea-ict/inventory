<?php
if(!defined('BASEPATH')) exit('No direct script access allowed');
	
class Auth extends CI_Controller{

public function __construct() {
     parent::__construct();
        $this->load->database();
		$this->load->model('auth_model');
        $this->load->library(array('form_validation'));
        $this->load->helper(array('url', 'language'));
    }


	public function index(){
	$data = array(
		'change' => 0, 
	);

		$this->load->view("admin", $data);
          
	}
	public function create(){
		$this->load->view("admin");
		$change = 1;
	}
	
	public function load_login(){
	
		 $data = array(
	    'message' => set_value('message'),
	    'identity' => set_value('identity'),
	    'password' => set_value('password'),
	   // 'forgot_password' => set_value('forgot_password'),
	    );
		     
            $this->load->view('login', $data);
	} 
	
	public function logout(){
	
		$_SESSION['user_logged']=FALSE;
		redirect('Auth/load_login');
	
	}
	public function login() {
	
	        $this->form_validation->set_rules('identity', 'Email', 'required');
	        $this->form_validation->set_rules('password', 'Password', 'required');
			$this->form_validation->set_error_delimiters('<span class="text-danger">', '</span>');
			
	
        if ($this->form_validation->run() == FALSE) {
            $this->load_login();
        } else {
		           // $data1[1] = $_POST['identity'];
					//$data1[2] = md5($_POST['password']);
					
					
					$this->load->model('auth_model');
					$fetch = $this->auth_model->get_by_id($this->input->post('identity', TRUE));
					if($fetch){
					$top = $fetch->email;
					$bottom = $fetch->password;
					if((($this->input->post('identity', TRUE)) == $top) && (($this->input->post('password', TRUE))==$bottom)){
					$data = array(
						'change' => 0,
					);
						$_SESSION['user_logged']=TRUE;
						$_SESSION['username']=$fetch->email;
						$this->load->view('admin', $data);
					}
					else{
					$this->session->set_flashdata("error","<div class = 'alert alert-danager'> Incorrect login in. <br/>consider checking 						your Email or password</div>");
			   		 $this->load_login();
					}
				
        } else{
			$this->session->set_flashdata("error","<div class = 'alert alert-danager'> Incorrect login in. <br/>Consider checking 						your Email or password</div>");
			   		 $this->load_login();
		}
		}
		
        
    }
	
	
}
?>
