
        <!-- Main content -->
        <section class='content'>
          <div class='row'>
            <div class='col-xs-12'>
              <div class='box'>
                <div class='box-header'>
                <h3 class='box-title'>Distribution Read</h3>
			<!--	 <table class="table table-bordered table-striped" id="mytable">
            <thead>
                <tr>
                    <th width="80px">No</th>
		    <th>Advisory</th>
			<th>Region</th>
		    <th>Date From</th>
		    <th>Date To</th>
		    <th>Issuetime</th>
		    <th>Action</th>
                </tr>
            </thead>
			<tbody> -->
			
			
			
			<table class="table table-bordered table-striped" id="mytable">
            <thead>
                <tr>
             <th width="80px">No</th>
		    <th>Name</th>
			<th>Number</th>
		    <th>Status</th>
			<th>Received by</th>
                </tr>
            </thead>
	    <tbody>
           <?php
            $start = 0;
			//$id = $this->input->post('prod', TRUE);
            foreach ($distribution_data as $distribution)
			
            {
			$reg = $this->db->get_where('product',array('id'=>$distribution->item_name));
                ?>
                <tr>
		    <td><?php echo ++$start ?></td>
			<td><?php foreach ($reg->result() as $p){ echo $p->item_name ; }//echo $distribution->item_name  ?></td>
			<td><?php echo $distribution->qty ?></td>
			<td><?php echo $distribution->status ?></td>
			<td><?php echo $distribution->receiver_name ?></td>
	        </tr>
                <?php
            }
            ?>
			<tr><td></td><td style="text-align:center" width="140px">
			<a href="<?php echo site_url('/distribution/index') ?>" class="btn btn-default">Back</a>
		    </td></tr>
            </tbody>
        </table>
			
			
			
        </div><!-- /.box-body -->
              </div><!-- /.box -->
            </div><!-- /.col -->
          </div><!-- /.row -->
        </section><!-- /.content -->