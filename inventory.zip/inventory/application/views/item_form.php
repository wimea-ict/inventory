<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Item Form</title>
<link href="assets/css/bootstrap.css" rel="stylesheet">
    <!--external css-->
    <link href="assets/font-awesome/css/font-awesome.css" rel="stylesheet" />
    <link rel="stylesheet" type="text/css" href="assets/js/bootstrap-datepicker/css/datepicker.css" />
    <link rel="stylesheet" type="text/css" href="assets/js/bootstrap-daterangepicker/daterangepicker.css" />
        
    <!-- Custom styles for this template -->
    <link href="assets/css/style.css" rel="stylesheet">
    <link href="assets/css/style-responsive.css" rel="stylesheet">
</head>

<body>
<h3> FILL ITEM FORM</h3>
<div class="row mt">
     <div class="col-lg-12">
            <div class="form-panel">
			<?php echo validation_errors(); ?>
 <form class="form-horizontal style-form" method="post" action = "<?php echo $action?>">
                          <div class="form-group">
                              <label class="col-sm-2 col-sm-2 control-label">Item Name</label>
                              <div class="col-sm-10">
                                  <input type="text" class="form-control" name="item_name" placeholder="Enter Item Name">
                              </div>
                          </div>
						  <div class="form-group">
                              <label class="col-sm-2 col-sm-2 control-label">Category</label>
                              <div class="col-sm-10">
                                <select name="category" class="form-control">
				<option value="Sensors">Sensors</option>
				<option value="Controllers">Controllers</option>
				<option value="Others">Others</option>
				</select> 
				
                              </div>
                          </div>
						  <div class="form-group">
                              <label class="col-sm-2 col-sm-2 control-label">Quantity</label>
                              <div class="col-sm-10">
                                  <input type="text" class="form-control" name="qty" placeholder="Enter number brought">
                              </div>
                          </div>
						
						  <div class="form-group">
                              <label class="col-sm-2 col-sm-2 control-label">Date</label>
                              <div class="col-sm-10">
                                  <input type="date" class="form-control form-datetime" id="date" name="date" readonly data-inputmask="'alias': 'yyyy-mm-dd'" data-mask=""  placeholder="yyyy-mm-dd">
                              </div>
                          </div>
						  <button type="submit" name="add" class="btn btn-primary" align = "right"><span class="glyphicon glyphicon-check"></span> Submit</button>
        <button type="reset" name="reset" class="btn btn-danger"><span class="glyphicon glyphicon-remove-sign"></span> Reset</button>
      
                      </form>
					  </div>
					  </div>
					  </div>
</body>
</html>
