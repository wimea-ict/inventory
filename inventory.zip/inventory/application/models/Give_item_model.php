<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class Give_item_model extends CI_Model
{

    public $table = 'item_out';
    public $id = 'id';
    public $order = 'DESC';

    function __construct()
    {
        parent::__construct();
    }

    // get all
    function get_all()
    {
	
	$this->db->select('*');
	$this->db->group_by('item_name');
	//$query = $this->db->get('item_name','destination');
        return $this->db->get($this->table)->result();
      //  $this->db->order_by($this->id, $this->order);
        //return $this->db->get($this->table)->result();
    }
    //get all replaced
    function get_all_replaced()
    {
        $this->db->select('daily_forecast.id,daily_forecast.max_temp,daily_forecast.min_temp,daily_forecast.sunrise,daily_forecast.sunset,daily_forecast.wind,daily_forecast.weather,daily_forecast.advisory,daily_forecast.datetime,season.season_name');
	$this->db->from('daily_forecast');
	$this->db->join('season','daily_forecast.season_id = season.id');
	return $this->db->get()->result();
	}
  // get data by id
    function get_by_id($id)
    {
        $this->db->where($this->id, $id);
        return $this->db->get($this->table)->row();
    }
    //get by id replaced
    function get_by_id_replaced($id)
    {
        $this->db->select('product.item_name,product.qty');
	$this->db->from('product');
	$this->db->where('product.id',$id);
	return $this->db->get()->row();
}
  // get total rows
    function total_rows($q = NULL) {
        $this->db->like('id', $q);
	$this->db->or_like('max_temp', $q);
	$this->db->or_like('min_temp', $q);
	$this->db->or_like('sunrise', $q);
	$this->db->or_like('sunset', $q);
	$this->db->or_like('wind', $q);
	$this->db->or_like('weather', $q);
	$this->db->or_like('advisory', $q);
	$this->db->or_like('datetime', $q);
	$this->db->from($this->table);
        return $this->db->count_all_results();
    }

    // get data with limit and search
    function get_limit_data($limit, $start = 0, $q = NULL) {
        $this->db->order_by($this->id, $this->order);
        $this->db->like('id', $q);
	$this->db->or_like('max_temp', $q);
	$this->db->or_like('min_temp', $q);
	$this->db->or_like('sunrise', $q);
	$this->db->or_like('sunset', $q);
	$this->db->or_like('wind', $q);
	$this->db->or_like('weather', $q);
	$this->db->or_like('advisory', $q);
	$this->db->or_like('datetime', $q);
	$this->db->limit($limit, $start);
        return $this->db->get($this->table)->result();
    }

    // insert data
    function insert($data2)
    { 
	// var_dump($data);
	 //exit;
      $sql = "INSERT INTO $this->table(id, item_name, qty, status, receiver_name, receiver_contact, destination) VALUES(null, ?, ?, ?, ?, ?, ?)";
		  $ww = $this->db->query($sql, $data2);
    }
	
/*function insert(){
	$sql = "INSERT INTO item_out(id, item_name, qty, status, receiver_name, receiver_contact, destination) VALUES(null, ?, ?, ?, ?, ?, ?)";
		  $ww = $this->db->query($sql, $data);
}*/
    // update data
    function update($id, $data)
    {
        $this->db->where($this->id, $id);
        $this->db->update($this->table, $data);
    }
	
    // delete data
    function delete($id)
    {
        $this->db->where($this->id, $id);
        $this->db->delete($this->table);
    }
	function abc(){
		 $sql = "INSERT INTO product_out(id, item_name, category, qty, date) VALUES(null, ?, ?, ?, ?)";
		  $ww = $this->db->query($sql, $data);
	}

}

/* End of file Daily_forecast_model.php */
