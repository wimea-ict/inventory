<?php
if (!defined('BASEPATH'))
    exit('No direct script access allowed');
class return_item extends CI_Controller{

	  function __construct()
    {
        parent::__construct();
        $this->load->model('return_item_model');
		//$this->load->model('update_item_model');
        $this->load->library('form_validation');
		
    }

public function index()
    { 
	$item = $this->return_item_model->get_all();
	$data = array(
		'item_data' => $item,
		'change' => 14,
	);
$this->load->view('admin', $data);
    }
	
/*public function return()
    { 
	$item = $this->update_item_model->get_all();
	$data = array(
		'item_data' => $item,
		'change' => 14,
	);
$this->load->view('admin', $data);
    }
*/

	public function create() 
    	{
        $data = array(
            'button' => 'add',
            'action' => site_url('/add_item/create_action'),
	    'id' => set_value('id'),
	    'item_name' => set_value('item_name'),
	    'category' => set_value('category'),
	    'qty' => set_value('qty'),
	    'date' => set_value('date'),
		'change'  => 1,
	);
        $this->load->view('admin', $data);
    }
    
    public function create_action() 
    {
//	echo "ssss";
	//exit;
	        $this->form_validation->set_rules('item_name', 'item name', 'required');
	$this->form_validation->set_rules('category', 'category', 'required');
	$this->form_validation->set_rules('qty', 'qty', 'required|numeric');
	$this->form_validation->set_rules('date', 'date', 'required');
	
	$this->form_validation->set_rules('id', 'id', 'trim');

        if ($this->form_validation->run() == FALSE) {
            $this->create();
        } else {
            $data = array(
		'item_name' => $this->input->post('item_name',TRUE),
		'category' => $this->input->post('category',TRUE),
		'qty' => $this->input->post('qty',TRUE),
		'date' => $this->input->post('date',TRUE),
	    );
		
              
            $this->add_item_model->insert($data);
			$data = array(
			   'change' => 1,
			);
            $this->session->set_flashdata('message', 'Item added');
             $this->load->view('admin',$data);
        }
    }
	

public function update($id) 
    {
        $row = $this->return_item_model->get_by_id($id);

        if ($row) {
            $data = array(
                'button' => 'Update',
                'action' => site_url('index.php/return_item/update_action'),
		'id' => set_value('id', $row->id),
		'item_name' => set_value('item_name', $row->item_name),
		'qty' => set_value('qty', $row->qty),
		'status' => set_value('status', $row->status),
		'receiver_name' => set_value('receiver_name', $row->receiver_name),
		'receiver_contact' => set_value('receiver_contact', $row->receiver_contact),
		'destination' => set_value('destination', $row->destination),
		'change'   => 15,
	    );
            $this->load->view('admin', $data);
        } else {
		$data = array(
		   'change'   => 4,
	    );
            $this->session->set_flashdata('message', 'Record Not Found');
            $this->load->view('admin', $data);
        }
    }
    
    public function update_action() 
    {
       // $this->_rules();

      //  if ($this->form_validation->run() == FALSE) {
        //    $this->update($this->input->post('id', TRUE));
        //}
		 //else {
		 
		 //$data['id'] = $this->input->post('id');
		 //echo "dlkdfldfkl";
		 
	     //echo $row->qty;
		 //exit;
	   //echo $row->qty;
	   //echo $qty1;
	   //exit;
	   $row = $this->return_item_model->get_by_id($this->input->post('id', TRUE));
	   // echo $this->input->post('id', TRUE);
		 //echo $row->qty;
		 //exit;
	   $qty1 = $row->qty;
	   $qs = ($this->input->post('numm', TRUE));
	   if($qs<=$qty1&&$qs>=1){
	   $qty = $qty1 - $qs;
	  // echo $qty;
	   //exit;
	  
            $data = array(
			'qty' => $qty,
		//'qty' => $this->input->post('numm',TRUE),
		//'id' => $this->input->post('id', TRUE),
		//'item_name' => $this->input->post('name',TRUE),
		
		//'issuetime' => $this->input->post('issuetime',TRUE),
	    );
		
		
			$this->load->model('return_item_model');
            $this->return_item_model->update($this->input->post('id', TRUE), $data);
			
			$this->load->model('update_item_model');
			$data = array(
				//'item_name' => $item_name,
				'qty' => $qty,
			);
			$fetch = $this->update_item_model->get_by_id($this->input->post('names', TRUE));
			$top = $fetch->qty;
			$second = $fetch->original_qty;
			//echo $top, $second;
			//exit;
			
			$bottom = $top + ($this->input->post('numm', TRUE));
			//echo $bottom;
			//exit;
			
			$data = array(
				'qty' => $bottom,
				'original_qty' => $second,
			);
			
			$this->load->model('update_item_model');
            $this->update_item_model->update($this->input->post('names', TRUE), $data);
			//echo $top;
			//exit;
			
			//$this->load->model('update_item_model');
			//$rows = $this->update_item_model->get_by_id($this->input->post('names', TRUE));
			//echo $this->input->post('names', TRUE);
			//exit;
			
			//echo $rows->qty;
			//exit;
			$data = array(
		   'change'   => 14,
	    );
            $this->session->set_flashdata('message', 'Update Record Success');
            $this->load->view('admin',$data);
      //  }
	  } else{
	  $data = array(
	  	'change' => 16,
	  );
	  $this->load->view("admin" ,$data);
	  /*	$this->session->set_flashdata('message', 'Number Invalid');
	
				  if($this->session->flashdata('message')){?>
				  
			      <div class = "alert alert-danger"><?php echo $this->session->flashdata('message');?></div>  
		             <?php }    ?>
<?php*/
	  		//echo "Number invalid";
			//exit;
	  }
    }


	/*
	 public function update() 
    {
	
	
	$this->load->model('update_item_model');
	$item = $this->update_item_model->get_all();
	$data = array(
		'item_data' => $item,
		'change' => 15,
	);
	$this->load->view('admin', $data);
		$id = $this->input->post('prod', TRUE);
		$num1 = $this->input->post('numm', TRUE);
		$store = $this->input->post('destination', TRUE);
		$date = $this->input->post('date', TRUE);
		//echo  , $num1, $store, $date;
		//exit;
        $row = $this->return_item_model->get_by_id($id);
	     //echo $row->qty;
		 //exit;
	   $qty1 = $row->qty;
	   
	   //echo $qty1;
	   //exit;
	   //$qty2 = $row->original_qty;
	   $qty = $qty1-$num1;
	   //echo $qty;
	   //exit;
	 //  $qtty = $qty2+$num;
	   //echo $qty;
		//exit;
		
        if ($row) {
		    
            $data = array(
		    'qty' => $qty,
		//	'original_qty' => $qtty,
			
	    );
		
		
		$this->load->model('return_item_model');
		$this->return_item_model->update($id, $data);
		//var_dump($data);
		//exit;
		$this->load->model('update_item_model');
		 $row2 = $this->update_item_model->get_by_id($store);
		  $qty2 = $row2->qty;
		  //echo $qty2;
		  //exit;
	   $qty3 = $qty2+$num1;
		 
		 $data = array(
                //'button' => 'Update',
                //'action' => site_url('index.php/give_item/update_action'),
		    'qty' => $qty3,
		//	'original_qty' => $qtty,
			
	    );
		$this->update_item_model->update($store, $data);
		$item = $this->update_item_model->get_all();
		//$this->give_item_model->insert($data);
		$data = array(
		'item_data' => $item,
			'change' => 14,
		);
            $this->load->view('admin', $data);
        } else {
            $this->session->set_flashdata('message', 'Record Not Found');
            $this->load->view('admin', $data);
        }
    }
    
    public function update_action() 
    {
       /* $this->_rules();

        if ($this->form_validation->run() == FALSE) {
            $this->update($this->input->post('id', TRUE));
        } else {
            $data = array(
		'qty' => $this->input->post('number',TRUE),
	    );

            $this->Advisory_model->update($this->input->post('id', TRUE), $data);
            $this->session->set_flashdata('message', 'Update Record Success');
	         $advisory = $this->Advisory_model->get_all();
	         $data = array(
			   'change' => 5,
              'advisory_data' => $advisory
             );
            $this->load->view('template',$data);
        }
    }*/
    
    public function delete($id) 
    {
        $row = $this->Advisory_model->get_by_id($id);
        $advisory = $this->Advisory_model->get_all();
	         $data = array(
			   'change' => 5,
              'advisory_data' => $advisory
             );
        if ($row) {
            $this->Advisory_model->delete($id);
            $this->session->set_flashdata('message', 'Delete Record Success');
             $this->load->view('template',$data);
        } else {
            $this->session->set_flashdata('message', 'Record Not Found');
             $this->load->view('template',$data);
        }
    }
	
	
	 public function _rules() 
    {
	$this->form_validation->set_rules('item_name', 'item name', 'trim|required');
	$this->form_validation->set_rules('qty', 'qty', 'trim|required|');
	$this->form_validation->set_rules('receiver_name', 'receiver_name', 'trim|required');
	$this->form_validation->set_rules('receiver_contact', 'receiver_contact', 'trim|required');
	
	$this->form_validation->set_rules('id', 'id', 'trim');
	$this->form_validation->set_error_delimiters('<span class="text-danger">', '</span>');
    }
	
	public function read() 
    {
	$id = $this->input->post('prod', TRUE);
	$row = $this->add_item_model->get_by_id_replaced($id);
	if ($row) {
            $data = array(
		'id' => $row->id,
		'item_name' => $row->item_name,
		'category' => $row->category,
		'qty' => $row->qty,
		'date' => $row-> date,
		'change' => 3,
	    );
            $this->load->view('admin', $data);
        } else {
            $this->session->set_flashdata('message', 'Record Not Found');
            redirect(site_url('admin'));
        }
    }

	
	}
	
	
	?>