
        <!-- Main content -->
        <section class='content'>
          <div class='row'>
            <div class='col-xs-12'>
              <div class='box'>
                <div class='box-header'>
                  <h3 class='box-title'>EQUIPMENT LIST</h3>
                </div><!-- /.box-header -->
                <div class='box-body'>
        <table class="table table-bordered table-striped" id="mytable">
            <thead>
                <tr>
                    <th width="80px">No</th>
			<th>Name</th>		
		    <th>Number</th>
		    <th>Status</th>
		    <th>Receeiver</th>
		    <th>Contact</th>
		    <th>Location</th>
		    <th>Return</th>
                </tr>
            </thead>
	    <tbody>
		
            <?php
            $start = 0;
            foreach ($this->return_item_model->get_all() as $item)
            {
				   // $sea = $this->db->get_where('season',array('id'=>$daily_forecast->season_id));
					$reg = $this->db->get_where('product',array('id'=>$item->item_name));
					 
                               
						
						
                ?>
                <tr>
		    <td><?php echo ++$start ?></td>
			<td><?php  foreach ($reg->result() as $p){ echo $p->item_name ; }?></td>
			<td><?php echo $item->qty ?></td>
			<td><?php echo $item->status ?></td>
			<td><?php echo $item->receiver_name ?></td>
			<td><?php echo $item->receiver_contact ?></td>
			<td><?php echo $item->destination ?></td>
		    <td style="text-align:center" width="140px">
			<?php 
			echo anchor(site_url('/return_item/update/'.$item->id),'<i class="glyphicon glyphicon-pencil"></i>',array('title'=>'edit','class'=>'btn btn-danger btn-sm')); 
			echo '  ';  
			?>
		    </td>
	        </tr>
                <?php
            }
            ?>
            </tbody>
        </table>
        <script src="<?php echo base_url('assets/frameworks/jquery/jquery.min.js') ?>"></script>
        <script src="<?php echo base_url('assets/plugins/datatables/jquery.dataTables.js') ?>"></script>
        <script src="<?php echo base_url('assets/plugins/datatables/dataTables.bootstrap.js') ?>"></script>
        <script type="text/javascript">
            $(document).ready(function () {
                $("#mytable").dataTable();
            });
        </script>
                    </div><!-- /.box-body -->
              </div><!-- /.box -->
            </div><!-- /.col -->
          </div><!-- /.row -->
        </section><!-- /.content -->