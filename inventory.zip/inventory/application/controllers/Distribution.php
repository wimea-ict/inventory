<?php
if (!defined('BASEPATH'))
    exit('No direct script access allowed');
class distribution extends CI_Controller{

	  function __construct()
    {
        parent::__construct();
        $this->load->model('distribution_model');
        $this->load->library('form_validation');
    }

public function index()
    { 
	
$item = $this->distribution_model->get_all();
	$data = array(
			'change' => 9,
            'item_data' => $item,
        );

        $this->load->view('admin', $data);
    }


	public function create() 
    	{
        $data = array(
            'button' => 'add',
            'action' => site_url('/add_item/create_action'),
	    'id' => set_value('id'),
	    'item_name' => set_value('item_name'),
	    'category' => set_value('category'),
	    'qty' => set_value('qty'),
		'original_qty' => set_value('confirm_qty'),
	    'date' => set_value('date'),
		'change'  => 1,
	);
        $this->load->view('admin', $data);
    }
    
    public function create_action() 
    {
//	echo "ssss";
	//exit;
	        $this->form_validation->set_rules('item_name', 'item name', 'required');
	$this->form_validation->set_rules('category', 'category', 'required');
	$this->form_validation->set_rules('qty', 'qty', 'required|numeric');
	$this->form_validation->set_rules('date', 'date', 'required');
	
	$this->form_validation->set_rules('id', 'id', 'trim');

        if ($this->form_validation->run() == FALSE) {
            $this->create();
        } else {
            $data = array(
		'item_name' => $this->input->post('item_name',TRUE),
		'category' => $this->input->post('category',TRUE),
		'qty' => $this->input->post('qty',TRUE),
		'original_qty' => $this->input->post('qty',TRUE),
		'date' => $this->input->post('date',TRUE),
	    );
		
              
            $this->add_item_model->insert($data);
			$data = array(
			'action' => site_url('/add_item/create_action'),
			   'change' => 1,
			);
            $this->session->set_flashdata('message', 'Item added');
             $this->load->view('admin',$data);
        }
    }
	
	//public function view(){
		
		//$data = array(
		//'change' => 2,
		//);
		//$this->load->view('admin', $data);
		//$this->load->view('admin', $data);
	//}
	
	 public function update($id) 
    {
	    //echo $id;
		//exit;
        $row = $this->add_item_model->get_by_id($id);

        if ($row) {
            $data = array(
                'button' => 'Update',
                'action' => site_url('index.php/Advisory/update_action'),
		'record_id' => set_value('id', $row->record_id),
		'region' => set_value('region', $row->region),
		'type' => set_value('type', $row->type),
		'advise' => set_value('advise', $row->advice),
		'msg' => set_value('msg', $row->message),
		'change' => 9,
	    );
            $this->load->view('template', $data);
        } else {
            $this->session->set_flashdata('message', 'Record Not Found');
            $this->load->view('template', $data);
        }
    }
    
    public function update_action() 
    {
        $this->_rules();

        if ($this->form_validation->run() == FALSE) {
            $this->update($this->input->post('id', TRUE));
        } else {
            $data = array(
		'msg' => $this->input->post('msg',TRUE),
	    );

            $this->Advisory_model->update($this->input->post('id', TRUE), $data);
            $this->session->set_flashdata('message', 'Update Record Success');
	         $advisory = $this->Advisory_model->get_all();
	         $data = array(
			   'change' => 5,
              'advisory_data' => $advisory
             );
            $this->load->view('template',$data);
        }
    }
    
    public function delete($id) 
    {
        $row = $this->Advisory_model->get_by_id($id);
        $advisory = $this->Advisory_model->get_all();
	         $data = array(
			   'change' => 5,
              'advisory_data' => $advisory
             );
        if ($row) {
            $this->Advisory_model->delete($id);
            $this->session->set_flashdata('message', 'Delete Record Success');
             $this->load->view('template',$data);
        } else {
            $this->session->set_flashdata('message', 'Record Not Found');
             $this->load->view('template',$data);
        }
    }
	
	public function read() 
    {
	$id1 = $this->input->post('prod', TRUE);
	
	//echo $id;
	//exit;
	//$decadal_forecast = $this->Decadal_forecast_model->get_all();
	$distribution = $this->distribution_model->get_by_id_replaced($id1);
	$id1 = $this->input->post('prod', TRUE);
	if ($distribution) {
	
            $data = array(
			'distribution_data' => $distribution,
		/*'id' => $result->id,
		'item_name' => $result->item_name,
		'qty' => $result->qty,
		'status' => $result->status,*/
		'change' => 11,
	    );
            $this->load->view('admin', $data);
        } else {
            $this->session->set_flashdata('message', 'Record Not Found');
            redirect(site_url('admin'));
        }
    }

	 public function _rules() 
    {
	$this->form_validation->set_rules('item_name', 'item name', 'trim|required');
	$this->form_validation->set_rules('category', 'category', 'trim|required|');
	$this->form_validation->set_rules('qty', 'qty', 'trim|required|numeric');
	$this->form_validation->set_rules('date', 'date', 'trim|required');
	
	$this->form_validation->set_rules('id', 'id', 'trim');
	$this->form_validation->set_error_delimiters('<span class="text-danger">', '</span>');
    }
	}
	
	
	?>