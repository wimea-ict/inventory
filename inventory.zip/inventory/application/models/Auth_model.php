<?php 
class Auth_model extends CI_Model{

public $table = 'users';
public $id = 'email';
function __construct()
    {
        parent::__construct();
    }

public function login1($data1)
	{   
	$a = $_POST['identity'];
	$b = $_POST['password'];
	
		$sql = "SELECT * FROM $this->table WHERE email = '$a' AND password = '$b'";
		  $ww = $this->db->query($sql);
		  /*$this->db->select('*');
			       $this->db->from('users');
			       $this->db->where(array('email' => $data1[1], 'password' => $data1[2] ));
		           return $this->db->get(); */
		
	}
	
	function get_by_id($id)
    {
        $this->db->where($this->id, $id);
        return $this->db->get($this->table)->row();
    }
	
	}
?>
