<!DOCTYPE HTML>
<html>
<head>
<title>Inventory Log In</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="Minimal Responsive web template, Bootstrap Web Templates, Flat Web Templates, Android Compatible web template, 
Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyEricsson, Motorola web design" />
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
<link href="<?php echo base_url() ?>assets3/css/bootstrap.min.css" rel='stylesheet' type='text/css' />
<!-- Custom Theme files -->
<link href="<?php echo base_url() ?>assets3/css/style.css" rel='stylesheet' type='text/css' />
<link href="<?php echo base_url() ?>assets3/css/font-awesome.css" rel="stylesheet"> 
<script src="<?php echo base_url() ?>assets3/js/jquery.min.js"> </script>
<script src="<?php echo base_url() ?>assets3/js/bootstrap.min.js"> </script>
</head>
<body>
	<div class="login">
		<h1><a href="index.html">AWS INVENTORY </a></h1>
		<div class="login-bottom">
		<?php if($this->session->flashdata('error')){?>
			      <?php echo $this->session->flashdata('error');?> 
		             <?php } ?>
			<h2>Login</h2>
			<?php echo form_open('auth/login');?>
			<div class="col-md-12">
				<div class="login-mail">
				<?php echo form_error('identity') ?>
					<input type="email" name = 'identity' placeholder="username" required="" value="<?php echo $identity; ?>">
					<i class="fa fa-user"></i>
				</div>
				<div class="login-mail">
				<?php echo form_error('password') ?>
					<input type="password" name = 'password' placeholder="Password" required="" value = "<?php echo $password; ?>">
					<i class="fa fa-lock"></i>
				</div>
			</div>
			<div class="col-md-12 login-do">
				<label class="hvr-shutter-in-horizontal login-sub">
					<input type="submit" name = 'login' value="login">
					</label>
				<!--	<p>Do not have an account?</p>
				<a href="signup.php" class="hvr-shutter-in-horizontal">Signup</a> -->
			</div>
			
			<div class="clearfix"> </div>
			 <?php echo form_close();?>
		</div>
	</div>
		<!---->
<div class="copy-right">
            <p> &copy; 2017 Wimea-ict <a href="http://w3layouts.com/" target="_blank">copyrights reserved</a> </p>	   
</div>  
<!---->
<!--scrolling js-->
	<script src="<?php echo base_url() ?>assets3/js/jquery.nicescroll.js"></script>
	<script src="<?php echo base_url() ?>assets3/js/scripts.js"></script>
	<!--//scrolling js-->
</body>
</html>

